# Handoff: Bestiaire Symbaroum

## Overview
Application de gestion de bestiaire pour le jeu de rôle **Symbaroum**. Outil MJ (Maître du Jeu) utilisé en séance sur tablette 11" (iPad Pro ou équivalent Android). Le cas d'usage principal est la consultation rapide en combat — l'information doit être accessible en moins de 2 secondes.

## About the Design Files
Les fichiers dans ce bundle sont des **prototypes de référence créés en HTML/React** — ils montrent le look and feel et les interactions prévus, mais ne constituent pas du code de production à copier directement. La mission est de **recréer ces designs dans l'environnement cible existant** (React Native, Vue, Swift/SwiftUI, etc.) en utilisant ses patterns établis. Si aucun environnement n'existe encore, React + TypeScript est recommandé.

## Fidelity
**High-fidelity** — les maquettes sont pixel-proches du résultat attendu. Colors, typographie, espacement, interactions et états hover/active sont tous spécifiés. Le développeur doit recréer l'UI aussi fidèlement que possible en utilisant les librairies et patterns du codebase cible.

---

## Screens / Views

### 1. Liste des monstres (vue principale)

**Purpose:** Vue d'accueil. Paul scanne la liste pour trouver et ouvrir rapidement un monstre.

**Layout:**
- `topnav` fixe en haut — hauteur ~56px, flex row, padding 12px 20px
- `search-bar` sous la nav — hauteur ~52px, flex row, gap 10px, padding 12px 20px
- `list-view` scrollable — flex column, gap 8px, padding 16px 20px

**Monster Card:**
- Background: `#131109`, border: `1px solid #332d21`, border-radius: 6px, padding: 14px 18px
- Layout: CSS Grid `1fr auto`, align-items: center
- **Compact mode** (tweak): padding 8px 14px, font-size nom 13px
- Hover: background `#1a1712`, border-color `#3d3628`
- Active (sélectionné): border-color `#8b5520`, background `#1f1508`

  **Côté gauche:**
  - Nom: Cinzel 15px/600, color `#e8d5a3`
  - Badge résistance (voir tokens)
  - Race: 12px, color `#7a6e52`
  - Barre d'endurance: 80px × 4px, border-radius 2px, bg `#2a251c`, fill coloré (vert/orange/rouge selon %)
  - Endurance texte: 11px, color `#7a6e52`
  - Warning seuil: "⚠ seuil" 10px rouge `#c84040` font-weight 600
  - KO: "✕ KO" même style

  **Côté droit:**
  - Stats preview: 3 colonnes (ATT / DÉF / END), label 9px uppercase `#7a6e52`, valeur 15px/600
    - ATT: couleur `#c84040`
    - DÉF: couleur `#4a7ab5`
    - END: couleur `#c87d2a`
  - Boutons "Éditer" (ghost) et "✕" (danger) — stopPropagation

**Search bar:**
- Input: background `#1a1712`, border `#332d21`, border-radius 4px, padding 8px 12px, font 13px
- Focus: border-color `#8b5520`
- Select filtre résistance: même style, width 160px
- Bouton "+ Ajouter": background `#c87d2a`, color `#0d0c0a`, border-radius 4px, padding 8px 16px

---

### 2. Fiche Monstre (vue détail) — PRIORITÉ ABSOLUE

**Purpose:** Consultation en combat. Info critique visible sans scroll sur tablette 11" landscape.

**Layout global:** flex column, overflow hidden
- Header fixe (hauteur ~70px)
- Body: CSS Grid `240px 1fr 280px`, 3 colonnes, overflow hidden, chaque colonne scrollable indépendamment

**Header:**
- Background `#131109`, border-bottom `1px solid #332d21`, padding 14px 20px
- Bouton "← Liste" ghost sm
- Nom: Cinzel 22px/700, color `#e8d5a3`
- Badge résistance
- Race · description tronquée: 12px `#7a6e52`
- **Tracker endurance** (côté droit):
  - Label "ENDURANCE" 11px uppercase `#7a6e52`
  - Valeur courante: Cinzel 26px/700, couleur dynamique (ambre/orange/rouge selon %)
  - " / max" 13px `#7a6e52` + "seuil N" 11px
  - Boutons − / + (padding 4px 10px, border bg2)
  - Bouton ↺ reset ghost sm
  - Barre 120px × 8px
- Bouton "Éditer" ghost sm

**Colonne 1 — Attributs (240px):**
- Section label: 9px/700 uppercase `#7a6e52`, border-bottom `#332d21`, mb 10px
- Table 8 stats: colonnes Stat | Brut | Eff.
  - En-têtes: 9px uppercase, "Eff." en couleur accent
  - Ligne Agilité (→ ATT): background `#140808`, texte `#c84040`
  - Ligne Précision (→ DÉF): background `#080f18`, texte `#4a7ab5`
  - Valeur brute: 13px/600 `#e8d5a3`
  - Valeur effective: 14px/700 couleur accent
  - Séparateur: border-bottom `#332d21`
- Armure (si présente): nom 12px + "Prot. N" 14px/700
- Notes MJ: 11px italic `#b8a87a`, line-height 1.6

**Colonne 2 — Combat (flex):**

*ATT. JOUEUR / DÉF. JOUEUR — les 2 éléments les plus importants:*
- Grid 2 colonnes, gap 10px
- Box ATT: background `#140808`, border `#3a1818`, border-radius 6px, padding 12px 14px, align center
  - Label "ATT. JOUEUR": 9px/700 uppercase, color `#c84040`
  - **Valeur: Cinzel 42px/700, color `#c84040`** ← doit sauter aux yeux
  - Sous-texte: "10 − Agilité (N)" 10px `#7a6e52`
- Box DÉF: même structure, couleurs `#4a7ab5` / border `#1a2a3a` / bg `#080f18`

*Défense + Dégâts:*
- Grid `90px 1fr`, gap 10px
- Box Défense: label 9px + valeur Cinzel 26px/700 `#e8d5a3` + note "base Agilité" 10px
- Box Dégâts: label + valeur 18px/700 couleur accent + note arme

*Application de dégâts:*
- Box bg2 border, padding 10px 14px
- Input numérique + bouton "Infliger" danger
- Enter → applique les dégâts
- Warnings: seuil de douleur (⚠) et KO (✕) en rouge bg `#1a0808`

*Équipement:*
- Items flex avec nom / dés accent / tags chips 9px bg3

**Colonne 3 — Capacités & Talents (280px):**

*Traits monstrueux groupés par type:*
- Badges de type:
  - Gratuit: `#5a8a3a` / bg `#0a120a` / border `#2a4a1a`
  - Réactif: `#4a7ab5` / bg `#080f1a` / border `#1a2a4a`
  - Actif: accent / bg amber-bg / border amber-dim
  - Passif: `#7a6e52` / bg bg2 / border border2
- Accordéon item: bg bg2 border border border-radius 5px
  - Header: flex space-between, padding 8px 12px, hover bg3
  - Nom: 13px/600, rang: 10px `#7a6e52`, chevron ▼ animé rotation 180°
  - Desc: 11px `#b8a87a` line-height 1.55, bg bg1, border-top, padding 8px 12px

*Talents (sous les capacités):*
- Même accordéon, avec badge de type inline (Actif/Réactif/Passif) détecté depuis le texte de description
- Section label "Talents" séparé

---

### 3. Formulaire Création / Édition

**Purpose:** Créer ou modifier un monstre. Utilisé hors combat.

**Layout:** Modal overlay (backdrop rgba 0,0,0,0.75) centré, max-width 760px, max-height 90vh, flex column
- Header: titre Cinzel 18px accent + bouton ✕
- Body scrollable: sections gap 20px
- Footer: Annuler (ghost) + Sauvegarder (primary)

**Sections:**
1. **Identité**: Nom* + Race* (grid 2 cols) + Description (textarea)
2. **Résistance & Endurance**: Select résistance + NumInput Endurance + NumInput Seuil (grid 3 cols)
3. **Attributs (5–15)**: Grid 4 cols, 8 stats avec NumInput custom (− val +)
4. **Traits monstrueux**: Select trait + Select rang + Bouton Ajouter → liste avec × pour retirer
5. **Talents**: même pattern que traits
6. **Armes**: Select arme + Bouton Ajouter → liste
7. **Armure**: Select unique
8. **Notes de combat**: Textarea

**NumInput custom:**
- Flex row: bouton − | valeur | bouton +
- Background bg2, border, border-radius 4px
- Boutons: bg bg3, hover bg4
- Valeur: 14px/600 center, bg transparent

**Form inputs:**
- Background `#1a1712`, border `#332d21`, border-radius 4px, padding 8px 12px
- Focus: border-color `#8b5520`
- Placeholder: `#7a6e52`
- Select: custom chevron SVG `%237a6e52`, padding-right 28px

---

## Interactions & Behavior

### Navigation
- Click card liste → ouvre fiche détail
- Bouton "← Liste" → retour liste
- Boutons monstres dans topnav (vue détail) → switch rapide entre fiches
- Click nom dans topnav → retour liste

### Endurance Tracker
- Bouton − : décrémente current (min 0)
- Bouton + : incrémente current (max endurance)
- Bouton ↺ : remet à max
- Input dégâts: valeur numérique, Enter ou bouton "Infliger" → soustrait
- Warning seuil: affiché si `current <= seuil && current > 0`
- Warning KO: affiché si `current === 0`
- Barre: couleur selon ratio — >60% ambre, >30% orange, ≤30% rouge

### Accordéon capacités/talents
- Click header → toggle description
- Chevron ▼ rotate 180° à l'ouverture (transition 0.2s)

### Suppression
- Click ✕ sur card → dialog de confirmation (modal bloquant)
- Confirmer → supprime + retour liste si c'était le monstre actif

### Formulaire
- Ajouter trait/talent: select + rang → append à la liste, select reset
- Retirer: click × sur item
- Sauvegarder: validation nom requis, update ou création, redirect vers fiche
- Annuler: retour sans sauvegarder

### Tweaks (optionnels en prod)
- **Liste compacte**: padding cards réduit, font-size 13px
- **Abréviations stats**: affiche PRC/AST/DIS/PRS/AGI/VOL/FOR/VIG avant le nom complet
- **Couleur accentuation**: swap des variables CSS `--amber` / `--amber2` / `--amber-dim` / `--amber-bg`

---

## State Management

```
monsters: Monster[]          // liste persistée en localStorage
selectedId: number | null    // monstre ouvert en détail
view: 'list' | 'detail' | 'form'
editTarget: Monster | null   // null = création

// par monstre:
enduranceCurrent: number     // tracker live (persisté)
```

**Calculs dérivés (pas stockés):**
- `ATT_joueur = 10 − agilite`
- `DEF_joueur = 10 − precision`
- `defense = agilite − (vigoureux_rank_modifier)`  // Vigoureux I: −1, II: −2, III: −3
- `degats = arme.dice + (poigne_de_fer ? +1d4/1d6/1d8 selon rang : '')`

**Persistance localStorage:**
- `sym_monsters` → JSON array complet
- `sym_lastView` → 'list' | 'detail'
- `sym_lastId` → id du dernier monstre ouvert

---

## Design Tokens

### Colors
```
--bg:          #0d0c0a   // fond principal
--bg1:         #131109   // nav, cartes
--bg2:         #1a1712   // surfaces élevées
--bg3:         #221e17   // boutons, hover
--bg4:         #2a251c   // éléments interactifs
--border:      #332d21   // séparateurs principaux
--border2:     #3d3628   // séparateurs secondaires

--text:        #e8d5a3   // texte principal (parchment)
--text2:       #b8a87a   // texte secondaire
--text3:       #7a6e52   // texte tertiaire / labels

// Accent (3 variantes via tweak):
// Ambre (défaut):
--amber:       #c87d2a
--amber2:      #e8952a
--amber-dim:   #8b5520
--amber-bg:    #1f1508

// Émeraude:
--amber:       #3a9a60
--amber2:      #50ba78
--amber-dim:   #1a6a3a
--amber-bg:    #081508

// Carmin:
--amber:       #c84040
--amber2:      #e85858
--amber-dim:   #8b2020
--amber-bg:    #1f0808

// Fixed semantic colors:
--red:         #c84040   // ATT joueur, danger, dégâts
--blue:        #4a7ab5   // DÉF joueur
--green:       #5a8a3a   // résistance Faible
```

### Résistance badges
| Valeur | Couleur texte | Border | BG |
|---|---|---|---|
| Faible | `#6a9a4a` | `#3a5a2a` | `#0a120a` |
| Ordinaire | `#b8a87a` | `#3d3628` | `#1a1712` |
| Résistant | `#7ab5e8` | `#2a4a6a` | `#080f18` |
| Éprouvante | `#c87d2a` | `#8b5520` | `#1f1508` |
| Légendaire | `#c870c8` | `#5a2a5a` | `#120a12` |

### Typography
```
Cinzel (Google Fonts, weights 400/600/700)  → titres, valeurs numériques clés
Inter  (Google Fonts, weights 300/400/500/600) → tout le reste
```

### Spacing
- Base unit: 4px
- Gaps standards: 6, 8, 10, 12, 16, 20px
- Border radius: 3px (badges), 4px (inputs/boutons), 5px (accordéon), 6px (cards/boxes), 8px (modal)

### Shadows
- Modal: `0 8px 32px rgba(0,0,0,0.6)`

---

## Data Model

```typescript
interface Monster {
  id: number;
  name: string;
  race: string;
  resistance: 'Faible' | 'Ordinaire' | 'Résistant' | 'Éprouvante' | 'Légendaire';
  endurance: number;        // max
  enduranceCurrent: number; // live tracker
  seuil: number;            // seuil de douleur
  stats: {
    precision: number;    // 5–20
    astuce: number;
    discretion: number;
    persuasion: number;
    agilite: number;
    volonte: number;
    force: number;
    vigilance: number;
  };
  traits: { id: string; rank: 'I' | 'II' | 'III' }[];
  talents: { id: string; rank: 'I' | 'II' | 'III' }[];
  weapons: Weapon[];
  armor: Armor;
  description: string;
  notes: string;
}

interface Weapon {
  id: string;
  name: string;
  dice: string;   // ex: "1d8"
  bonus: string;  // ex: "+1 DGT"
  tags: string[]; // ex: ["Court", "Naturel"]
}

interface Armor {
  id: string;
  name: string;
  protection: number;
  tags: string[];
}
```

---

## Assets
- **Police Cinzel**: Google Fonts (`family=Cinzel:wght@400;600;700`)
- **Police Inter**: Google Fonts (`family=Inter:wght@300;400;500;600`)
- Pas d'images ou d'icônes externes — tout est en CSS/texte

---

## Files
- `Bestiaire Symbaroum.html` — prototype complet interactif (React + Babel inline). Contient les 3 écrans, les données de test, et toute la logique d'interaction. À ouvrir dans un navigateur pour référence live.
